const discord = require('discord.js');

var client = new discord.Client();

const token = "NjQ2MTI0NTU3NzczNTcwMDcw.XdMlBw.9uHvGKTgUpA62QIa4mteGKhmmgI";

client.on ("Ready", () => {
    console.log("Ready!");

    client.user.setGame ("YEEt");
});

const fs = require("fs");

client.msgs = require ("./msgs.json");

const prefix ="tb!";
client.on("message", (message) => {
    if (message.author.bot) return;

    if(message.content.startsWith (prefix + "hello")){
        message.reply ("Hi");

        message.channel.send("message: " + message);
        message.channel.send("message sender: " + message.author.username);
        message.channel.send("message sender ID: " + message.author.id);
    }

    if (message.content.startsWith ("👀")){
        message.channel.send(":eyes:");
    }

    if (message.content.startsWith ("obama")) {
        message.channel.send("Who doesn't like obama prism?", {files: ["obama.jpg"]});
    }

    if (message.content.startsWith ("write")) {
        editedmessage = message.content.slice (6);
        
        client.msgs [message.author.username] = {
            message: editedmessage
        }
        fs.writeFile ("./msgs.json", JSON.stringify (client.msgs, message.author.username, null, 4), err =>{
            if (err) throw err;
            message.channel.send("message written");
        });
    
    }
    if (message.content.startsWith ("read")){
        let _message = client.msgs[message.author.username].message;
        let _username = client.msgs[message.author.username].Client;
        message.channel.send("message is : " + _message + _username);
    }
});

client.login (token);